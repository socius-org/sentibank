# sentibank
Unifying sentiment lexicons and dictionaries into an accessible open python package 
